<template>
  <div id="app">
    <ProductListOne/>
    <ProductListTwo/>

  </div>
</template>
<script>
import ProductListOne from './components/ProductListOne'
import ProductListTwo from './components/ProductListTwo'
export default {
  components:{
    ProductListOne,
    ProductListTwo
  },
  name:'app',
  
  
}
</script>
<style>
body{
  font-family: Ubuntu;
  color:#555
}
</style>